-- Weekly base table last_updated_on update --
use #STG_TABLE_SCHEMA;

update #STG_TABLE_SCHEMA.history_snapshot_weekly_temp SRC
left join 
(
select SQ.issueid, SQ.sourceinstance, SQ.n_key, SQ.authorkey, max(SQ.last_updated_on) as last_updated_on
from (
select SRC.issueid, SRC.sourceinstance, SRC.n_key, chnglog.authorkey, max(convert_tz(chnglog.created,'<<TENANT_SSI_TIME_ZONE>>','<<DW_TARGET_TIME_ZONE>>')) as last_updated_on
from #STG_TABLE_SCHEMA.history_snapshot_weekly_temp SRC
left join #MDS_TABLE_SCHEMA.issue_changelog_final chnglog
on SRC.issueid=chnglog.issueid and SRC.sourceinstance=chnglog.sourceinstance
left join #MDS_TABLE_SCHEMA.issue_changelog_items_final chnglogitems
on chnglogitems.issuechangelogid = chnglog.id and chnglogitems.sourceinstance = chnglog.sourceinstance
left join #DWH_TABLE_SCHEMA.d_calendar_date cal
on SRC.n_key = cal.row_key
where date_format(convert_tz(chnglog.created,'<<TENANT_SSI_TIME_ZONE>>','<<DW_TARGET_TIME_ZONE>>'), '%Y-%m-%d') <= date_format(cal.week_end_date, '%Y-%m-%d')
group by SRC.issueid, SRC.sourceinstance, SRC.n_key
union all 
select SRC.issueid, SRC.sourceinstance, SRC.n_key, comments.authorkey, max(convert_tz(comments.created,'<<TENANT_SSI_TIME_ZONE>>','<<DW_TARGET_TIME_ZONE>>')) as last_updated_on
from #STG_TABLE_SCHEMA.history_snapshot_weekly_temp SRC
left join #MDS_TABLE_SCHEMA.issue_comments_final comments
on SRC.issueid=comments.issueid
and SRC.sourceinstance=comments.sourceinstance
left join #DWH_TABLE_SCHEMA.d_calendar_date cal
on SRC.n_key = cal.row_key
where date_format(convert_tz(comments.created,'<<TENANT_SSI_TIME_ZONE>>','<<DW_TARGET_TIME_ZONE>>'), '%Y-%m-%d') <= date_format(cal.week_end_date, '%Y-%m-%d')
group by SRC.issueid, SRC.sourceinstance, SRC.n_key
) SQ
group by SQ.issueid, SQ.sourceinstance, SQ.n_key
) base
on base.issueid = SRC.issueid and base.sourceinstance = SRC.sourceinstance and base.n_key = SRC.n_key
left join #DWH_TABLE_SCHEMA.d_work_item D
on concat(SRC.issueid, '') = D.row_id and SRC.sourceinstance = D.source_id
left join #DWH_TABLE_SCHEMA.d_calendar_date cal
on SRC.n_key = cal.row_key

set SRC.last_updated_on = case when date_format(D.changed_on, '%Y-%m-%d') <= date_format(cal.week_end_date, '%Y-%m-%d') then D.changed_on else coalesce(base.last_updated_on, D.created_on) end, SRC.changed_by = base.authorkey, SRC.updated_on = current_timestamp;

use #STG_TABLE_SCHEMA;

update #STG_TABLE_SCHEMA.history_snapshot_weekly_temp SRC
set SRC.changed_on = SRC.last_updated_on;