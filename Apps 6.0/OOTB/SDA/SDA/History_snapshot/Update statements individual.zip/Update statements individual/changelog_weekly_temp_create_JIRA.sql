-- Weekly changelog table creation --

drop table if exists #STG_TABLE_SCHEMA.weekly_changelog_id;

create table if not exists #STG_TABLE_SCHEMA.weekly_changelog_id 

select SRC.issueid,SRC.sourceinstance, SRC.n_key, SRC.lagging_count_of_weeks, chnglogitems.field, max(chnglogitems.issuechangelogid) as max_chnglog_id, min(chnglogitems.issuechangelogid) as min_chnglog_id
from #STG_TABLE_SCHEMA.history_snapshot_weekly_temp SRC
left join #MDS_TABLE_SCHEMA.issue_changelog_final chnglog
on SRC.issueid=chnglog.issueid
and SRC.sourceinstance=chnglog.sourceinstance
left join #MDS_TABLE_SCHEMA.issue_changelog_items_final chnglogitems
on chnglogitems.issuechangelogid = chnglog.id and chnglogitems.sourceinstance = chnglog.sourceinstance
left join #DWH_TABLE_SCHEMA.d_calendar_date cal
on SRC.n_key = cal.row_key
where lower(chnglogitems.field) in ('status', 'assignee', 'priority', 'sprint', 'duedate', 'project', 'resolution') and
date_format(convert_tz(chnglog.created,'<<TENANT_SSI_TIME_ZONE>>','<<DW_TARGET_TIME_ZONE>>'), '%Y-%m-%d') <= date_format(cal.week_end_date, '%Y-%m-%d')
and coalesce(chnglogitems.`from`, '') <> coalesce(chnglogitems.`to`, '')
group by SRC.issueid,SRC.sourceinstance, SRC.n_key, SRC.lagging_count_of_weeks, chnglogitems.field

union all

select base.issueid, base.sourceinstance, base.n_key, base.lagging_count_of_weeks, base.field, cnglg.id as max_chnglog_id, cnglg.id as min_chnglog_id
from (
select SRC.issueid,SRC.sourceinstance, SRC.n_key, SRC.lagging_count_of_weeks, chnglogitems.field, min(coalesce(chnglogitems.to, chnglogitems.from)) as min_chnglog_id
from #STG_TABLE_SCHEMA.history_snapshot_weekly_temp SRC
left join #MDS_TABLE_SCHEMA.issue_changelog_final chnglog
on SRC.issueid=chnglog.issueid
and SRC.sourceinstance=chnglog.sourceinstance
left join #MDS_TABLE_SCHEMA.issue_changelog_items_final chnglogitems
on chnglogitems.issuechangelogid = chnglog.id and chnglogitems.sourceinstance = chnglog.sourceinstance
left join #DWH_TABLE_SCHEMA.d_calendar_date cal
on SRC.n_key = cal.row_key
where lower(chnglogitems.field) in ('fix version') and
date_format(convert_tz(chnglog.created,'<<TENANT_SSI_TIME_ZONE>>','<<DW_TARGET_TIME_ZONE>>'), '%Y-%m-%d') <= date_format(cal.week_end_date, '%Y-%m-%d') 
and coalesce(chnglogitems.`from`, '') <> coalesce(chnglogitems.`to`, '')
group by SRC.issueid,SRC.sourceinstance, SRC.n_key, SRC.lagging_count_of_weeks, chnglogitems.field
) base
left join #DWH_TABLE_SCHEMA.d_calendar_date cal
on base.n_key = cal.row_key
left join 
(
select chnglog.id, chnglog.issueid, chnglog.sourceinstance, chnglogitems.field, chnglogitems.to, chnglogitems.from, chnglog.created
from #MDS_TABLE_SCHEMA.issue_changelog_final chnglog
left join #MDS_TABLE_SCHEMA.issue_changelog_items_final chnglogitems
on chnglogitems.issuechangelogid = chnglog.id and chnglogitems.sourceinstance = chnglog.sourceinstance
where lower(chnglogitems.field) in ('fix version') and
coalesce(chnglogitems.`from`, '') <> coalesce(chnglogitems.`to`, '')
) cnglg
on coalesce(cnglg.to, cnglg.from) = base.min_chnglog_id and cnglg.issueid = base.issueid 
and cnglg.sourceinstance = base.sourceinstance and cnglg.field = base.field 
and date_format(convert_tz(cnglg.created,'<<TENANT_SSI_TIME_ZONE>>','<<DW_TARGET_TIME_ZONE>>'), '%Y-%m-%d') <= date_format(cal.week_end_date, '%Y-%m-%d') 

union all

select SRC.issueid,SRC.sourceinstance, SRC.n_key, SRC.lagging_count_of_weeks, chnglogitems.field, max(chnglogitems.issuechangelogid) as max_chnglog_id, min(chnglogitems.issuechangelogid) as min_chnglog_id
from #STG_TABLE_SCHEMA.history_snapshot_weekly_temp SRC
left join #MDS_TABLE_SCHEMA.issue_changelog_final chnglog
on SRC.issueid=chnglog.issueid
and SRC.sourceinstance=chnglog.sourceinstance
left join #MDS_TABLE_SCHEMA.issue_changelog_items_final chnglogitems
on chnglogitems.issuechangelogid = chnglog.id and chnglogitems.sourceinstance = chnglog.sourceinstance
left join #DWH_TABLE_SCHEMA.d_calendar_date cal
on SRC.n_key = cal.row_key
where lower(chnglogitems.field) in ('business value', 'story points', 'summary') and
date_format(convert_tz(chnglog.created,'<<TENANT_SSI_TIME_ZONE>>','<<DW_TARGET_TIME_ZONE>>'), '%Y-%m-%d') <= date_format(cal.week_end_date, '%Y-%m-%d')
and coalesce(chnglogitems.fromstring, '') <> coalesce(chnglogitems.tostring, '')
group by SRC.issueid,SRC.sourceinstance, SRC.n_key, SRC.lagging_count_of_weeks, chnglogitems.field;

drop table if exists #STG_TABLE_SCHEMA.changelog_weekly_temp;

create table if not exists #STG_TABLE_SCHEMA.changelog_weekly_temp (
  changelogid int(15) DEFAULT NULL,
  issueid varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, 
  sourceinstance bigint(20) NOT NULL DEFAULT 0,
  created datetime DEFAULT NULL,
  field varchar(128) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  fromstring text COLLATE utf8_unicode_ci DEFAULT NULL,
  tostring text COLLATE utf8_unicode_ci DEFAULT NULL,
  `from` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `to` text COLLATE utf8_unicode_ci DEFAULT NULL,
  n_key int(15) DEFAULT 0,
  lagging_count_of_weeks int(15) DEFAULT 0,
  
  PRIMARY KEY (changelogid, field, sourceinstance, n_key),
  KEY first_idx (issueid, sourceinstance, field, n_key) USING BTREE,
  KEY second_idx (field) USING BTREE,
  KEY third_idx (changelogid, issueid, sourceinstance, field) USING BTREE,
  KEY fourth_idx (changelogid, sourceinstance) USING BTREE
);

insert into #STG_TABLE_SCHEMA.changelog_weekly_temp 
(changelogid, issueid, sourceinstance, created, field, fromstring, tostring, `from`, `to`, n_key, lagging_count_of_weeks)

select distinct base.id as changelogid, base.issueid, base.sourceinstance, base.created, base.field, base.fromstring, base.tostring, base.`from`, base.`to`, weekly.n_key, weekly.lagging_count_of_weeks
from 
(select chnglog.id, chnglog.issueid, chnglog.sourceinstance, chnglog.created, chnglogitems.field, chnglogitems.fromstring, chnglogitems.`from`, chnglogitems.`to`, chnglogitems.tostring
from #MDS_TABLE_SCHEMA.issue_changelog_final chnglog
left join #MDS_TABLE_SCHEMA.issue_changelog_items_final chnglogitems
on chnglogitems.issuechangelogid = chnglog.id and chnglogitems.sourceinstance = chnglog.sourceinstance
where lower(chnglogitems.field) in ('status', 'assignee', 'priority', 'sprint', 'duedate', 'project', 'resolution') and coalesce(chnglogitems.`from`, '') <> coalesce(chnglogitems.`to`, '')
) base

join #STG_TABLE_SCHEMA.weekly_changelog_id weekly
on weekly.max_chnglog_id = base.id and weekly.issueid = base.issueid and weekly.sourceinstance = base.sourceinstance and weekly.field = base.field

union all

select distinct base.id as changelogid, base.issueid, base.sourceinstance, base.created, base.field, base.fromstring, base.tostring, base.`from`, base.`to`, weekly.n_key, weekly.lagging_count_of_weeks
from 
(select chnglog.id, chnglog.issueid, chnglog.sourceinstance, chnglog.created, chnglogitems.field, chnglogitems.fromstring, chnglogitems.`from`, chnglogitems.`to`, chnglogitems.tostring
from #MDS_TABLE_SCHEMA.issue_changelog_final chnglog
left join #MDS_TABLE_SCHEMA.issue_changelog_items_final chnglogitems
on chnglogitems.issuechangelogid = chnglog.id and chnglogitems.sourceinstance = chnglog.sourceinstance
where lower(chnglogitems.field) in ('fix version') and coalesce(chnglogitems.`from`, '') <> coalesce(chnglogitems.`to`, '')
) base

join #STG_TABLE_SCHEMA.weekly_changelog_id weekly
on weekly.min_chnglog_id = base.id and weekly.issueid = base.issueid and weekly.sourceinstance = base.sourceinstance and weekly.field = base.field

union all 

select distinct base.id as changelogid, base.issueid, base.sourceinstance, base.created, base.field, base.fromstring, base.tostring, base.`from`, base.`to`, weekly.n_key, weekly.lagging_count_of_weeks
from 
(select chnglog.id, chnglog.issueid, chnglog.sourceinstance, chnglog.created, chnglogitems.field, chnglogitems.fromstring, chnglogitems.`from`, chnglogitems.`to`, chnglogitems.tostring
from #MDS_TABLE_SCHEMA.issue_changelog_final chnglog
left join #MDS_TABLE_SCHEMA.issue_changelog_items_final chnglogitems
on chnglogitems.issuechangelogid = chnglog.id and chnglogitems.sourceinstance = chnglog.sourceinstance
where lower(chnglogitems.field) in ('business value', 'story points', 'summary') and coalesce(chnglogitems.fromstring, '') <> coalesce(chnglogitems.tostring, '')
) base

join #STG_TABLE_SCHEMA.weekly_changelog_id weekly
on weekly.max_chnglog_id = base.id and weekly.issueid = base.issueid and weekly.sourceinstance = base.sourceinstance and weekly.field = base.field;

-- Weekly next changelog table creation --

drop table if exists #STG_TABLE_SCHEMA.next_changelog_val_week;

create table if not exists #STG_TABLE_SCHEMA.next_changelog_val_week 

select chnglog.id AS changelogid, chnglog.issueid, chnglog.sourceinstance, chnglogitems.field, chnglogitems.fromstring as next_fromstring, chnglogitems.`from` as next_from, next_id.n_key, next_id.lagging_count_of_weeks
from #MDS_TABLE_SCHEMA.issue_changelog_final chnglog
left join #MDS_TABLE_SCHEMA.issue_changelog_items_final chnglogitems
on chnglogitems.issuechangelogid = chnglog.id and chnglogitems.sourceinstance = chnglog.sourceinstance
join (
select SRC.issueid,SRC.sourceinstance, SRC.n_key, SRC.lagging_count_of_weeks, chnglogitems.field, min(chnglogitems.issuechangelogid) as nxt_chnglog_id
from #STG_TABLE_SCHEMA.history_snapshot_weekly_temp SRC
left join #MDS_TABLE_SCHEMA.issue_changelog_final chnglog
on SRC.issueid=chnglog.issueid
and SRC.sourceinstance=chnglog.sourceinstance
left join #MDS_TABLE_SCHEMA.issue_changelog_items_final chnglogitems
on chnglogitems.issuechangelogid = chnglog.id and chnglogitems.sourceinstance = chnglog.sourceinstance
left join #DWH_TABLE_SCHEMA.d_calendar_date cal
on SRC.n_key = cal.row_key
where lower(chnglogitems.field) in ('status', 'assignee', 'priority', 'sprint', 'duedate', 'project', 'resolution') and
date_format(convert_tz(chnglog.created,'<<TENANT_SSI_TIME_ZONE>>','<<DW_TARGET_TIME_ZONE>>'), '%Y-%m-%d') > date_format(cal.week_end_date, '%Y-%m-%d') and coalesce(chnglogitems.`from`, '') <> coalesce(chnglogitems.`to`, '')
group by SRC.issueid,SRC.sourceinstance, SRC.n_key, SRC.lagging_count_of_weeks, chnglogitems.field) next_id
on next_id.nxt_chnglog_id = chnglog.id and next_id.sourceinstance = chnglog.sourceinstance and next_id.issueid = chnglog.issueid and next_id.field = chnglogitems.field
where lower(chnglogitems.field) in ('status', 'assignee', 'priority', 'sprint', 'duedate', 'project', 'resolution')

union all

select cnglg.id AS changelogid, base.issueid, base.sourceinstance, base.field, cnglg.fromstring as next_fromstring, cnglg.`from` as next_from, base.n_key, base.lagging_count_of_weeks
from (
select SRC.issueid,SRC.sourceinstance, SRC.n_key, SRC.lagging_count_of_weeks, chnglogitems.field, min(coalesce(chnglogitems.to, chnglogitems.from)) as min_chnglog_id
from #STG_TABLE_SCHEMA.history_snapshot_weekly_temp SRC
left join #MDS_TABLE_SCHEMA.issue_changelog_final chnglog
on SRC.issueid=chnglog.issueid
and SRC.sourceinstance=chnglog.sourceinstance
left join #MDS_TABLE_SCHEMA.issue_changelog_items_final chnglogitems
on chnglogitems.issuechangelogid = chnglog.id and chnglogitems.sourceinstance = chnglog.sourceinstance
left join #DWH_TABLE_SCHEMA.d_calendar_date cal
on SRC.n_key = cal.row_key
where lower(chnglogitems.field) in ('fix version') and
date_format(convert_tz(chnglog.created,'<<TENANT_SSI_TIME_ZONE>>','<<DW_TARGET_TIME_ZONE>>'), '%Y-%m-%d') > date_format(cal.week_end_date, '%Y-%m-%d') and coalesce(chnglogitems.`from`, '') <> coalesce(chnglogitems.`to`, '')
group by SRC.issueid,SRC.sourceinstance, SRC.n_key, SRC.lagging_count_of_weeks, chnglogitems.field
) base
left join 
(
select chnglog.id, chnglog.issueid, chnglog.sourceinstance, chnglogitems.field, chnglogitems.to, chnglogitems.from, chnglogitems.fromstring
from #MDS_TABLE_SCHEMA.issue_changelog_final chnglog
left join #MDS_TABLE_SCHEMA.issue_changelog_items_final chnglogitems
on chnglogitems.issuechangelogid = chnglog.id and chnglogitems.sourceinstance = chnglog.sourceinstance
where lower(chnglogitems.field) in ('fix version') 
) cnglg
on coalesce(cnglg.from) = base.min_chnglog_id and cnglg.issueid = base.issueid 
and cnglg.sourceinstance = base.sourceinstance and cnglg.field = base.field

union all

select chnglog.id AS changelogid, chnglog.issueid, chnglog.sourceinstance, chnglogitems.field, chnglogitems.fromstring as next_fromstring, chnglogitems.`from` as next_from, next_id.n_key, next_id.lagging_count_of_weeks
from #MDS_TABLE_SCHEMA.issue_changelog_final chnglog
left join #MDS_TABLE_SCHEMA.issue_changelog_items_final chnglogitems
on chnglogitems.issuechangelogid = chnglog.id and chnglogitems.sourceinstance = chnglog.sourceinstance
join (
select SRC.issueid,SRC.sourceinstance, SRC.n_key, SRC.lagging_count_of_weeks, chnglogitems.field, min(chnglogitems.issuechangelogid) as nxt_chnglog_id
from #STG_TABLE_SCHEMA.history_snapshot_weekly_temp SRC
left join #MDS_TABLE_SCHEMA.issue_changelog_final chnglog
on SRC.issueid=chnglog.issueid
and SRC.sourceinstance=chnglog.sourceinstance
left join #MDS_TABLE_SCHEMA.issue_changelog_items_final chnglogitems
on chnglogitems.issuechangelogid = chnglog.id and chnglogitems.sourceinstance = chnglog.sourceinstance
left join #DWH_TABLE_SCHEMA.d_calendar_date cal
on SRC.n_key = cal.row_key
where lower(chnglogitems.field) in ('business value', 'story points', 'summary') and
date_format(convert_tz(chnglog.created,'<<TENANT_SSI_TIME_ZONE>>','<<DW_TARGET_TIME_ZONE>>'), '%Y-%m-%d') > date_format(cal.week_end_date, '%Y-%m-%d') and coalesce(chnglogitems.fromstring, '') <> coalesce(chnglogitems.tostring, '')
group by SRC.issueid,SRC.sourceinstance, SRC.n_key, SRC.lagging_count_of_weeks, chnglogitems.field) next_id
on next_id.nxt_chnglog_id = chnglog.id and next_id.sourceinstance = chnglog.sourceinstance and next_id.issueid = chnglog.issueid and next_id.field = chnglogitems.field
where lower(chnglogitems.field) in ('business value', 'story points', 'summary');


alter table #STG_TABLE_SCHEMA.next_changelog_val_week
ADD PRIMARY KEY (issueid, changelogid, field, sourceinstance, n_key),
ADD INDEX first_idx (issueid, sourceinstance, field, n_key) USING BTREE,
ADD INDEX second_idx (field) USING BTREE,
ADD INDEX third_idx (changelogid, issueid, sourceinstance, field) USING BTREE,
ADD INDEX fourth_idx (changelogid, sourceinstance) USING BTREE;