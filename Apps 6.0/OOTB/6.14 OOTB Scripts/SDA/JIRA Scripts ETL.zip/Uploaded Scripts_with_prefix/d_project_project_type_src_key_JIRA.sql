SELECT CASE WHEN count(1) > 0 THEN 'FAILURE' ELSE 'SUCCESS' END as Result,
 CASE WHEN count(1) >0 THEN 'MDS to DWH data validation failed for d_project.project_type_src_key' ELSE 'SUCCESS' END as Message
 FROM #MDS_TABLE_SCHEMA.project_final SRC 
 LEFT JOIN #DWH_TABLE_SCHEMA.d_lov LOV
 ON (concat('PROJECT_TYPE~',projecttypekey) = LOV.row_id 
 AND SRC.sourceinstance = LOV.source_id)
 LEFT JOIN #DWH_TABLE_SCHEMA.d_project TRGT 
 ON (concat(SRC.id, '')=TRGT.row_id 
 AND SRC.sourceinstance=TRGT.source_id)
 WHERE COALESCE(LOV.row_key, case when SRC.projecttypekey is null then 0 else -1 end)<> COALESCE(TRGT.project_type_src_key ,'');