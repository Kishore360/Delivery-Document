SELECT CASE WHEN count(1) > 0 THEN 'FAILURE' ELSE 'SUCCESS' END as Result,
CASE WHEN count(1) >0 THEN 'MDS to DWH data validation failed for d_lov_severity_work_item.dimension_class' ELSE 'SUCCESS' END as Message
FROM (select * from #MDS_TABLE_SCHEMA.priority_final where msvsts_common_severity is not null 
and msvsts_common_severity <> ''
group by msvsts_common_severity,sourceinstance) SRC 
LEFT JOIN #DWH_TABLE_SCHEMA.d_lov TRGT 
ON  ((CONCAT('SEVERITY~WORK_ITEM~',(SRC.msvsts_common_severity)))=TRGT.row_id 
AND SRC.sourceinstance=TRGT.source_id)
WHERE COALESCE('SEVERITY~WORK_ITEM','')<>COALESCE(TRGT.dimension_class,'')