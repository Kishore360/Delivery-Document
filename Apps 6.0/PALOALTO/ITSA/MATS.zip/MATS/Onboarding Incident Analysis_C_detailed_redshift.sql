select 'ldb.d_internal_contact_opened_by_c a11' as Table_name, count(a11.row_key) Row_Count
from ldb.d_internal_contact_opened_by_c a11 