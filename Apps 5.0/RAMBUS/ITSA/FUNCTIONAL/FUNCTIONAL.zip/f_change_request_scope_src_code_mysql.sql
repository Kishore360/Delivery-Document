

SELECT CASE WHEN cnt > 0 THEN 'FAILURE' ELSE 'SUCCESS' END AS Result
,
CASE WHEN cnt > 0 THEN 'Data did not Match.' 
ELSE 'Data Matched' END AS Message 

from(select count(1) as cnt
 
from  rambus_mdsdb.change_request_final b 

left outer join  rambus_mdwdb.f_change_request a 

on a.row_id =b.sys_id 

and a.source_id=b.sourceinstance

where coalesce(a.scope_src_code,'') <> coalesce(b.u_change_scale,'') ) z;