SELECT Max(a.state_duration)/86400.00
FROM ldb.f_incident_state a 
